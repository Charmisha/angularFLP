export class Products 
{
public prod_id: number;
 public prod_name: string;
 public prod_price: number;
 
}