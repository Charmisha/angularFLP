import { Component, OnInit ,Injector, RootRenderer, Injectable} from '@angular/core';
import { ProductService } from '../product.service';
import { Products } from '../products';
import { Cart } from '../cart';

@Component({
  selector: 'app-products-page',
  templateUrl: './products-page.component.html',
  styleUrls: ['./products-page.component.css']
})
export class ProductsPageComponent implements OnInit {


  productsList:Products;
  cart:Cart;

  constructor(private productService : ProductService) { 
    this.cart=new Cart();
  }
  

  ngOnInit() {
    this.getAllProducts();
  }

  getAllProducts()
  {
    this.productService.showProducts().subscribe(data=>
    this.productsList=data);
      //console.log(this.productsList);  
  }
  addProductToCart(data)
  {
   this.cart.prod_id=data.prod_id;
   this.cart.prod_price=data.prod_price;

   this.productService.addProductsToCart(this.cart).subscribe(data => {
    alert("Product added to Cart");
    });
   console.log("fhuyfy");  
    
  }

}
